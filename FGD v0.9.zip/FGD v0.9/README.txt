Hello!

Thank you for trying out my program!
It is by no means complete yet,
and I do plan to keep adding to it. You can use your own database of plant species etcetera and put it in the code.
I have added some instructions in the code itself but I do plan to put them on the GitHub aswell in the Future.

~Finn
