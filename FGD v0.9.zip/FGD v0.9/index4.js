const objects = [];

function calculateDistance(obj1, obj2) {
    const rect1 = obj1.getBoundingClientRect();
    const rect2 = obj2.getBoundingClientRect();
    
    const x1 = rect1.left + rect1.width / 2;
    const y1 = rect1.top + rect1.height / 2;
    
    const x2 = rect2.left + rect2.width / 2;
    const y2 = rect2.top + rect2.height / 2;
    
    const distance = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    
    return distance;
}

const cdInt = setInterval(calculateDistance, 100);

function startDragging(event) {
    const obj = event.target;
    const offsetX = obj.offsetWidth / 2; 
    const offsetY = obj.offsetHeight / 2; 
    
    const dragInfo = {
        obj,
        offsetX,
        offsetY
    };
    
    obj.dragInfo = dragInfo;
    
    obj.style.zIndex = '9999';
    
    const initialCursorX = obj.getBoundingClientRect().left + offsetX;
    const initialCursorY = obj.getBoundingClientRect().top + offsetY;
    
    event.clientX = initialCursorX;
    event.clientY = initialCursorY;
    
    // Prevent text selection during drag
    event.preventDefault();
}

function stopDragging(event) {
    const obj = event.target;
    
    if (obj.dragInfo) {
        obj.style.zIndex = '';

        obj.dragInfo = null;
        updateColors();
    }
}

function moveObject(event) {
    objects.forEach(obj => {
        if (obj.dragInfo) {
            const x = event.clientX - obj.dragInfo.offsetX;
            const y = event.clientY - obj.dragInfo.offsetY;
            obj.style.left = x + 'px';
            obj.style.top = y + 'px';
        }
    });
}

function changeColorForProximity(obj1, obj2, maxDistance, color) {
    const distance = calculateDistance(obj1, obj2);
    if (distance <= maxDistance) {
        obj1.style.backgroundColor = color;
        obj2.style.backgroundColor = color;
    } else {
        obj1.style.backgroundColor = '';
        obj2.style.backgroundColor = '';
    }
}

function resetColors(objects) {
    for (const obj of objects) {
        obj.style.backgroundColor = '';
    }
}

//update colors of objects based on custom factors
function updateColors() {
    for (let i = 0; i < objects.length; i++) {
        for (let j = i + 1; j < objects.length; j++) {
            const obj1 = objects[i];
            const obj2 = objects[j];

            if (
                obj1.classList.contains('hogeBoom') && obj2.classList.contains('hogeBoom')
            ) {
                changeColorForProximity(obj1, obj2, 280, 'red');
            } else if (
                obj1.classList.contains('lageBoom') && obj2.classList.contains('lageBoom')
            ) {
                changeColorForProximity(obj1, obj2, 240, 'red');
            } else if (
                (obj1.classList.contains('hogeBoom') && obj2.classList.contains('lageBoom')) ||
                (obj1.classList.contains('lageBoom') && obj2.classList.contains('hogeBoom'))
            ) {
                changeColorForProximity(obj1, obj2, 260, 'red');
            } else if (
                (obj1.classList.contains('hogeBoom') && obj2.classList.contains('struik')) ||
                (obj1.classList.contains('struik') && obj2.classList.contains('hogeBoom'))                
            ) {
                changeColorForProximity(obj1, obj2, 130, 'red');
            } else if (
                (obj1.classList.contains('lageBoom') && obj2.classList.contains('struik')) ||
                (obj1.classList.contains('struik') && obj2.classList.contains('lageBoom'))                
            ) {
                changeColorForProximity(obj1, obj2, 90, 'red');
            } /*else if (
                (obj1.classList.contains(' ') && obj2.classList.contains(' ')) ||
                (obj1.classList.contains(' ') && obj2.classList.contains(' '))                
            ) {
                changeColorForProximity(obj1, obj2, 120, 'red');
            }*/

        }
    }
}



//test response
const ucinterval = setInterval(updateColors, 100);
const logtest = setInterval(console.log("test"), 100);

document.addEventListener('mousemove', moveObject);

//add buttons and names for your plants here
const spawnButton1 = document.getElementById('spawnButton1');
const spawnButton2 = document.getElementById('spawnButton2');
const spawnButton3 = document.getElementById('spawnButton3');
const spawnButton4 = document.getElementById('spawnButton4');
const spawnButton5 = document.getElementById('spawnButton5');
const spawnButton6 = document.getElementById('spawnButton6');
//const spawnButton7 = document.getElementById('spawnButton7');

spawnButton1.addEventListener('click', () => spawnObject('hogeBoom'));
spawnButton2.addEventListener('click', () => spawnObject('lageBoom'));
spawnButton3.addEventListener('click', () => spawnObject('struik'));
spawnButton4.addEventListener('click', () => spawnObject('kruid'));
spawnButton5.addEventListener('click', () => spawnObject('kruiplaag'));
spawnButton6.addEventListener('click', () => spawnObject('wortel'));
//spawnButton7.addEventListener('click', () => spawnObject(' '));

function spawnObject(className) {
    const spawnArea = document.getElementById('spawnArea');
    const newObject = document.createElement('div');
    newObject.className = 'object ' + className;
    
    const maxX = spawnArea.clientWidth - 50;
    const maxY = spawnArea.clientHeight - 50;
    const randomX = Math.random() * maxX;
    const randomY = Math.random() * maxY;
    
    newObject.style.left = randomX + 'px';
    newObject.style.top = randomY + 'px';
    
    newObject.addEventListener('mousedown', startDragging);
    newObject.addEventListener('mouseup', stopDragging);
    
    objects.push(newObject);
    spawnArea.appendChild(newObject);
    
    logDistances();
    updateColors();
}

function logDistances() {
    for (let i = 0; i < objects.length; i++) {
        for (let j = i + 1; j < objects.length; j++) {
            const distance = calculateDistance(objects[i], objects[j]);
            console.log(`Distance between Object ${i + 1} and Object ${j + 1}: ${distance.toFixed(2)} pixels`);
        }
    }
}

//photo uploader
let bgPhoto = document.getElementById("bgphoto");
let inputFile = document.getElementById("input-file");
inputFile.onchange = function(){
    bgPhoto.src = URL.createObjectURL(inputFile.files[0]);

}